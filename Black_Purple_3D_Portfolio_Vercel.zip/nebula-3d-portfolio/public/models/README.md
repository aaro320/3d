Place your published .glb models in this folder. Reference them in code using /models/filename.glb.
