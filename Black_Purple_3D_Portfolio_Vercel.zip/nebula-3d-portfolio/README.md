# NOIR / VIOLET — Interactive 3D Portfolio

A working black-and-purple 3D artist portfolio powered by Vite and Three.js. Includes animated hero, three sample procedural artworks, interactive orbit viewer, local `.glb` preview, About, Skills, and Contact.

## Run locally

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev` and open the URL printed in the terminal.
5. Run `npm run build` to verify production output.

## Deploy to GitHub and Vercel

1. Create a new GitHub repository and push all files in this folder (not the enclosing ZIP).
2. On Vercel, choose **Add New → Project** and import your repository.
3. Framework: **Vite** (or Other if not auto-detected). Root directory: folder containing `package.json`.
4. Build command: `npm run build`; output directory: `dist`.
5. Click Deploy. Future pushes to your production branch automatically redeploy.

## Personalize

- In `src/main.js`, replace `Your Name`, the biography, skills, and `yourname@example.com`.
- Change the sample project entries in the `projects` array.
- To add your own `.glb` models permanently, place files in `public/models/` and use `GLTFLoader` with a path such as `/models/my-work.glb`. The file chooser on the live page is for **local preview only**, not publishing.
- A `.gltf` with external textures or binary buffers may not load from the local picker; prefer self-contained `.glb` files.

## Notes

- Requires a browser with WebGL support.
- The font uses Google Fonts; it will fall back to system fonts offline.
- No backend or database is needed for this portfolio. For user-managed uploads or a content dashboard, add a backend later.
